"""
Pre-event OSM snapshot through the Overpass *attic* date feature: FALLBACK when the ohsome API refuses geometry requests (HTTP 403).

Compliance (data rules: "OpenStreetMap as it was before the event"):
  * EVERY query starts with  [date:"<snapshot>T00:00:00Z"]  and the snapshot must be STRICTLY BEFORE the event date. Without that header Overpass returns TODAY's map
    (post-event edits => disqualification), so build_query() refuses to produce a query without it and a test enforces it.
  * This is the only module allowed to talk to Overpass (tests/test_compliance.py).
Output has the same shape as ohsome results: a GeoJSON FeatureCollection whose properties are the OSM tags plus '@osmId' ("way/123").
Limits: relations (e.g. multipolygon buildings) are skipped and counted; coverage of the attic database should be checked on the first live run.
"""
from __future__ import annotations

import logging
import time
from datetime import date
from typing import Any, Optional

import requests
from shapely.geometry import LineString, Point, Polygon, mapping, shape

from app.config import get_config

logger = logging.getLogger(__name__)

HEADERS = {"User-Agent": "FloodLens-Nepal/0.4 (educational hackathon prototype; python-requests)"}
QUERY_TIMEOUT_S = 180
HTTP_TIMEOUT_S = 200
RETRIES = 3
RETRY_DELAY_S = 10.0
LAYER_PAUSE_S = 3.0          # the public servers rate-limit bursts of queries
LAST_ERROR: dict[str, str] = {}
# layer name used by osm_snapshot._fetch  ->  kind
POINT_KINDS = {"settlements", "towns", "health"}
KIND_BY_NAME = {"buildings": "buildings", "roads": "roads", "bridges": "bridges",
                "villages": "settlements", "towns": "towns", "health": "health"}


def _rx(values) -> str:
    return "^(" + "|".join(values) + ")$"


def _body(kind: str, bb: str) -> str:
    cfg = get_config()
    if kind == "buildings":
        return f'way["building"]({bb});'
    if kind == "roads":
        return f'way["highway"~"{_rx(cfg["osm"]["motorable_highway_tags"])}"]({bb});'
    if kind == "bridges":
        return f'way["bridge"]["bridge"!="no"]({bb});'
    if kind == "settlements":
        return f'node["place"~"{_rx(["village", "hamlet", "suburb", "neighbourhood", "locality"])}"]({bb});'
    if kind == "towns":
        return f'node["place"~"{_rx(["town", "city"])}"]({bb});'
    if kind == "health":
        types = _rx(cfg["accessibility"]["target_health_types"])
        return (f'node["amenity"~"{types}"]({bb}); way["amenity"~"{types}"]({bb});'
                f'node["healthcare"~"{_rx(["hospital", "clinic"])}"]({bb}); way["healthcare"~"{_rx(["hospital", "clinic"])}"]({bb});')
    raise ValueError(f"unknown OSM layer kind {kind!r}")


def build_query(kind: str, bounds: tuple[float, float, float, float], snapshot: date, event: date) -> str:
    """Overpass QL with an explicit attic date. Refuses snapshot >= event."""
    if snapshot >= event:
        raise ValueError(f"OSM snapshot {snapshot} must be STRICTLY BEFORE event date {event}. Post-event OSM edits are not permitted.")
    minx, miny, maxx, maxy = bounds
    bb = f"{miny:.6f},{minx:.6f},{maxy:.6f},{maxx:.6f}"        # Overpass order: south,west,north,east
    q = f'[out:json][timeout:{QUERY_TIMEOUT_S}][date:"{snapshot.isoformat()}T00:00:00Z"];({_body(kind, bb)});out geom;'
    assert '[date:"' in q                                       # belt and braces: never send an undated query
    return q


def _to_feature(el: dict, kind: str) -> Optional[dict]:
    tags = dict(el.get("tags") or {})
    props = {**tags, "@osmId": f'{el["type"]}/{el["id"]}'}
    if el["type"] == "node" and kind not in POINT_KINDS:
        return None
    if el["type"] == "way" and kind in ("settlements", "towns"):
        return None
    if el["type"] == "node":
        if "lat" not in el:
            return None
        geom = mapping(Point(el["lon"], el["lat"]))
    elif el["type"] == "way":
        pts = [(g["lon"], g["lat"]) for g in el.get("geometry", []) if g]
        if len(pts) < 2:
            return None
        closed = len(pts) >= 4 and pts[0] == pts[-1]
        if kind in ("buildings", "health") and closed:
            geom = mapping(Polygon(pts))
        elif kind == "buildings":
            return None                                           # an unclosed building way is not a polygon
        else:
            geom = mapping(LineString(pts))
    else:
        return None
    return {"type": "Feature", "properties": props, "geometry": geom}


def to_geojson(overpass_json: dict, kind: str, aoi: dict) -> dict:
    poly = shape(aoi)
    feats, skipped_rel = [], 0
    for el in overpass_json.get("elements", []):
        if el.get("type") == "relation":
            skipped_rel += 1
            continue
        ft = _to_feature(el, kind)
        if ft and shape(ft["geometry"]).intersects(poly):
            feats.append(ft)
    if skipped_rel:
        logger.info("Overpass %s: %d relations skipped (multipolygons not assembled)", kind, skipped_rel)
    return {"type": "FeatureCollection", "features": feats}


def fetch_layer(name: str, aoi: dict[str, Any], snapshot: date, event: date) -> Optional[dict]:
    kind = KIND_BY_NAME[name]
    LAST_ERROR.pop(name, None)
    time.sleep(LAYER_PAUSE_S)
    query = build_query(kind, shape(aoi).bounds, snapshot, event)
    urls = get_config()["osm"].get("overpass_urls", ["https://overpass-api.de/api/interpreter"])
    for url in urls:
        for attempt in range(1, RETRIES + 1):
            try:
                r = requests.post(url, data={"data": query}, headers=HEADERS, timeout=HTTP_TIMEOUT_S)
                if r.status_code == 200:
                    js = r.json()
                    if "remark" in js and "timed out" in str(js["remark"]).lower():
                        LAST_ERROR[name] = "server-side timeout"
                        logger.warning("Overpass %s: server-side timeout (%s)", kind, js["remark"])
                        break
                    return to_geojson(js, kind, aoi)
                LAST_ERROR[name] = f"HTTP {r.status_code}"
                logger.warning("Overpass %s HTTP %d (attempt %d/%d, %s): %s", kind, r.status_code, attempt, RETRIES, url,
                               " ".join(r.text.split())[:200])
                if r.status_code in (400, 403):
                    break
            except (requests.exceptions.RequestException, ValueError) as exc:
                LAST_ERROR[name] = type(exc).__name__
                logger.warning("Overpass %s attempt %d/%d failed: %s", kind, attempt, RETRIES, exc)
            time.sleep(RETRY_DELAY_S * attempt)
    return None
