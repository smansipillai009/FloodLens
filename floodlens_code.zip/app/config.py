"""
FloodLens Nepal — central config loader.

Every tunable threshold lives in configs/config.yaml and is read here.
`config_hash()` returns a SHA-256 of the config file; `scripts/freeze_config.py`
stores it in configs/config.lock BEFORE any check-only reference data is opened.
"""
from __future__ import annotations

import copy
import hashlib
import math
from functools import lru_cache
from pathlib import Path
from typing import Any, Optional

import yaml

ROOT = Path(__file__).resolve().parent.parent

try:  # credentials (CDSE_CLIENT_ID / CDSE_CLIENT_SECRET) live in <repo>/.env, never in git
    from dotenv import load_dotenv
    load_dotenv(ROOT / ".env", override=False)
except ImportError:  # python-dotenv missing: real environment variables still work
    pass

CONFIG_PATH = ROOT / "configs" / "config.yaml"
LOCK_PATH = ROOT / "configs" / "config.lock"


@lru_cache(maxsize=1)
def _load(path: str) -> dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def get_config(path: Optional[Path] = None) -> dict[str, Any]:
    """Return a deep copy of the config so callers can't mutate the cache."""
    return copy.deepcopy(_load(str(path or CONFIG_PATH)))


def config_hash(path: Optional[Path] = None) -> str:
    return hashlib.sha256((path or CONFIG_PATH).read_bytes()).hexdigest()


def locked_hash() -> Optional[str]:
    if LOCK_PATH.exists():
        return LOCK_PATH.read_text(encoding="utf-8").split()[0].strip()
    return None


def utm_crs_for_lonlat(lon: float, lat: float) -> str:
    """UTM EPSG code for a location (fixes the old hard-coded EPSG:32645,
    which is wrong for western Nepal, lon < 84 E)."""
    zone = int(math.floor((lon + 180) / 6) + 1)
    return f"EPSG:{(32600 if lat >= 0 else 32700) + zone}"


def utm_crs_for_geom(geojson_geom: dict) -> str:
    from shapely.geometry import shape
    c = shape(geojson_geom).centroid
    return utm_crs_for_lonlat(c.x, c.y)
